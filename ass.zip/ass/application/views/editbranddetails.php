
<?php
$id=$taskInfo->id;
$name=$taskInfo->name;
$logo=$taskInfo->logo;
$website=$taskInfo->website_url;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
    }

    h2 {
        color: #333;
    }

    form {
        max-width: 400px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    input[type="text"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
    }

    button[type="submit"] {
        padding: 10px 20px;
        background-color: #333;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
</style>



    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Brand Details</title>
    <!-- Add your CSS includes here -->
</head>
<body>
<h2 style="color: #333; text-align: center; margin-top: 20px;">Edit Brand Details</h2>

    <?php echo form_open_multipart('admin/edit_brand');?>

    <div>
        <label for="id">ID:</label>
        <input type="text" value="<?php echo $id; ?>" name="id" id="id" />
       
    </div>
    <div>
        <label for="name">Brand Name:</label>
        <input type="text" value="<?php echo $name; ?>" name="name" id="name" />
        
    </div>
    <div>
        <label for="logo">Logo URL:</label>
        <input type="file" id="logo"  name="logofile"  required>
    </div>
    <div>
        <label for="website_url">Website URL:</label>
        <input type="text" id="website_url" value="<?php echo $website; ?>" name="website_url" required>
    </div>
    <button type="submit">Save Changes</button>
</form>

</body>
</html>
