<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Class : Login_model (Login Model)
 * Login model class to get to authenticate user credentials 
 * 
 */
class Login_model extends CI_Model
{

    /**
     * This function used to check the login credentials of the user
     * @param string $name : This is name of the user
     * @param string $password : This is encrypted password of the user
     */
    function loginMe($username, $password)
    {
        $this->db->select('id', 'username', 'password');
        $this->db->from('admin'); //table 

        $this->db->where('username', $username);
        $this->db->where('password', $password);
        $query = $this->db->get();

        $user = $query->row();

        // return $user;
        if ($user) {
            return 'Yes';

        } else {
            return 'No';

        }



    }
    function Add_Brand($name, $logo, $website)
    {
        $data = array(
            'name' => $name,
            'logo' => $logo,
            'website_url' => $website
        );
        //insert data into database table.  
        $this->db->insert('brands', $data); //table
        $insert_id = $this->db->insert_id();
        
        echo "<strong>Brand Added Successfully!</strong>";
    }
    public function getlist()
    {

        $this->db->select('id, name, logo, website_url');
        $this->db->from('brands');
        $query = $this->db->get();

        return $query->result();
    }
    function getTaskInfo($taskId)
    {
        $this->db->select('id,name, logo, website_url');
        $this->db->from('brands');
        $this->db->where('id', $taskId);
        
        $query = $this->db->get();
        
        return $query->row();
    
    }
    

    public function edit_brand($id, $name, $logo, $website)
    {
        $data = array(
            'id' => $id,
            'name' => $name,
            'logo' => $logo,
            'website_url' => $website
        );

        $this->db->where('id', $id);
        $this->db->update('brands', $data);

        return $this->db->affected_rows() > 0;
    }

}







?>