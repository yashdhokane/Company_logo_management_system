<!DOCTYPE html>
<html>

<head>
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <style>
    /* Custom styles */
    body {
      background-color: #f8f9fa;
    }

    .navbar {
      background-color: #343a40;
      border-radius: 0;
    }

    .navbar-brand {
      font-size: 24px;
      font-weight: bold;
      margin-left: 10px;
      color: white;
    }

    .navbar-toggler-icon {
      background-color: white;
    }

    .nav-link {
      color: white;
      font-weight: bold;
      padding: 8px 20px;
      border-radius: 5px;
      transition: background-color 0.3s, color 0.3s;
    }

    .nav-link:hover {
      background-color: #212529;
      color: white;
    }

    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
      margin-top: 20px;
    }

    .card-header {
      background-color: #343a40;
      color: white;
      font-size: 20px;
      font-weight: bold;
    }

    table {
      background-color: white;
      border-radius: 5px;
      box-shadow: 0px 2px 10px rgba(0, 0, 0, 0.1);
    }

    th {
      font-size: 16px;
      font-weight: bold;
      background-color: #f8f9fa;
      padding: 10px 15px;
      text-align: center;
    }

    td {
      font-size: 14px;
      padding: 10px 15px;
      text-align: center;
    }

    .btn-danger {
      background-color: #dc3545;
      border-color: #dc3545;
    }

    .btn-danger:hover {
      background-color: #c82333;
      border-color: #bd2130;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg">
    <div class="container-fluid">
     
      <a class="navbar-brand" href="#">Admin</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01"
        aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarColor01">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="btn btn-light" href="<?= base_url('index.php/admin/showbrand') ?>">List</a>&nbsp;&nbsp;
          </li>
          <li class="nav-item">
            <a class="btn btn-light" href="<?= base_url('index.php/admin/dashboard') ?>">Add</a>&nbsp;&nbsp;
          </li>
          <li class="nav-item">
            <a class="btn btn-light" href="<?= base_url(); ?>">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container">
    <div class="col-md-12 card">
      <div class="card-header">Brand List</div>
      <table class="table table-hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Logo</th>
            <th>Website</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!empty($records)) { foreach ($records as $record) { ?>
          <tr>
            <td><?php echo $record->id; ?></td>
            <td><?php echo $record->name; ?></td>
            <td width="20%">
              <?php $imgpath = base_url('uploads/') . $record->logo; ?>
              <div style="width: 80px; margin: 0 auto;">
                <img src="<?= $imgpath ?>" alt="logo" width="80px" height="80px" >
              </div>
              <a href="<?= $imgpath ?>" target="new">Download</a>
            </td>
            <td><?php echo $record->website_url; ?></td>
            <td><a class="btn btn-secondary"
                href="<?php echo base_url() . 'index.php/Admin/update_brand/' . $record->id; ?>"
                title="Edit">Edit</a></td>
          </tr>
          <?php } } ?>
        </tbody>
      </table>
