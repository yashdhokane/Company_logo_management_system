<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        //load Helper for Form
        $this->load->helper('url', 'form');
        $this->load->library('form_validation');
        $this->load->database();
        $this->load->model('login_model');

    }

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/userguide3/general/urls.html
     */
    public function index()
    {


        $this->load->view('login');
        // redirect('dashboard');
    }
    public function login()
    {



        $username = $this->input->post('username'); //catch data 
        $password = $this->input->post('password');
        // echo $username;
        // echo $password;
        $result = $this->login_model->loginMe($username, $password);
        // print_r($result);
        if ($result == 'Yes') {
            header("Location: dashboard");
        } else {
            $this->load->view('login');

        }



    }
    public function dashboard()
    {
        $this->load->view('dashboard');
    }
    public function Add()
    {
        $name = $this->input->post('name'); //catch data 
        $logo = "";
        $website = $this->input->post('website_url'); //catch data 

        $config['upload_path'] = './uploads';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 100000;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('logofile')) {
            $error = array('error' => $this->upload->display_errors());
            print_r($error);
            echo "error";
            // $this->load->view('upload_form', $error);
        } else {
            $data = $this->upload->data();

            //print_r($data['file_name']);
            $logo = $data['file_name'];
            echo "uploeded...";
        }
        $result = $this->login_model->Add_Brand($name, $logo, $website);
        header("Location: showbrand");


    }

    public function showbrand()
    {
        $data['records'] = $this->login_model->getlist();

        // print_r($data['records']);
        $this->load->view("brand_list", $data);
    }


    public function update_brand($id = NULL)
    {

        // echo $Id;


        $data['taskInfo'] = $this->login_model->getTaskInfo($id);
        $this->load->view("editbranddetails", $data);
        //print_r($data);
    }
    public function edit_brand()
    {
        $id = $this->input->post('id');
        $name = $this->input->post('name');
        $logo = "";
        $website = $this->input->post('website_url');

        //upload function
        $config['upload_path'] = './uploads';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 100000;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('logofile')) {

            //  print_r($error);
            echo "error";
            // $this->load->view('upload_form', $error);
        } else {
            $data = $this->upload->data(); // store data file _name ,size

            //print_r($data['file_name']);
            $logo = $data['file_name'];
            // echo "uploeded...";
        }
        $this->login_model->edit_brand($id, $name, $logo, $website);

        $data['records'] = $this->login_model->getlist();

        // print_r($data['records']);
        $this->load->view("brand_list", $data);

    }






}