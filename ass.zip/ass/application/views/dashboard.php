<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0; 
            background-color: #f8f9fa;
        }

        nav {
            background-color: black;
            color: #fff;
            padding: 10px;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        nav ul li {
            margin-right: 15px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        .container {
            margin: 20px;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .container h2 {
            margin-top: 0;
        }

        .container form label {
            display: block;
            margin-bottom: 5px;
        }

        .container form input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        .container form button[type="submit"] {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }
        .a{
            
            color: white;
        }
    
        .nav-container {
            display: flex;
            align-items: center;
        }

        .nav-box {
            background-color: black;
            padding: 8px 16px;
            border-radius: 5px;
            margin: 0 10px;
            
        }

        .nav-box:hover {
            background-color: #0056b3;
        }

        .a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#" style="color:white;">Admin</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="btn btn-light" href="<?= base_url('index.php/admin/showbrand') ?>">List 
          </a>
        </li>
        <li class="nav-item">
          <a class="btn btn-light" href="<?= base_url('index.php/admin/dashboard') ?>">Add</a>
        </li>
        <li>
            <a class="btn btn-light" href="<?= base_url(); ?>">Logout</a>
        </li>
      </ul> 
    </div>
  </div>
</nav> 

    <div class="container">
        <div class="card">
        <h2>Add Brand</h2>
        <form action="<?= base_url('index.php/admin/Add') ?>" method="post" >
        <?php //echo form_open_multipart('admin/Add');?>
            <label for="name">Brand Name:</label>
            <input type="text" name="name" required>
            <br>
            <label for="logo"> Upload Logo :</label>
            <input type="file" name="logofile" required>
            <br>
            <label for="website_url">Website URL:</label>
            <input type="text" name="website_url" required>
            <br>
            <button type="submit">Add Brand</button>
        </form>
        </div>
    </div>
</body>
</html>
