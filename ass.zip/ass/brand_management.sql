-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2023 at 04:11 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brand_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='admin login';

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `website_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Brands management database ';

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `logo`, `website_url`) VALUES
(1, 'WhatsApp ', '2.JPG', 'www.whatsapp.com'),
(2, 'Walmart ', '51.JPG', 'www.walmart.com'),
(3, 'Saudi Aramco', '31.JPG', 'www.aramco.com'),
(4, 'Iocl', '41.JPG', 'www.iocl.com'),
(5, 'BSNL', '81.JPG', 'www.bsnl.co.in'),
(6, 'pepsi', '71.JPG', 'www.pepsico.com'),
(7, 'google', '11.JPG', 'www.google.com'),
(8, 'ONGC', '6.JPG', 'www.ongc.com'),
(9, 'Relience', '10.JPG', 'www.relience.com'),
(10, 'hdfc bank', '9.JPG', 'www.hdfc.com'),
(11, 'SBI', '14.JPG', 'www.sbi.com'),
(12, 'facebook', '12.JPG', 'www.facebook.com'),
(13, 'oneplus', '151.JPG', 'www.oneplus.in'),
(14, 'youtube', '13.JPG', 'www.youtube.com'),
(15, 'xampp', '17.JPG', 'www.xampp.com'),
(16, 'accer', '19.JPG', 'www.accer.com'),
(17, 'chatgpt', '18.JPG', 'www.chatgpt.com'),
(18, 'Codignitor', '16.JPG', 'www.codignitor.com'),
(19, 'TATA STEEL', '20.JPG', 'www.tatasteel.com'),
(20, 'Infosys', '24.JPG', 'www.infosys.com'),
(21, 'Vedanta', '22.JPG', 'www.vendanta.com'),
(22, 'ICIC Bank ', '23.JPG', 'www.icicbank.com'),
(23, 'Jsw Steel', '21.JPG', 'www.jswsteel.com'),
(24, 'NTPC', '28.JPG', 'www.ntpc.com'),
(25, 'ITC', '26.JPG', 'www.itc.com'),
(26, 'HDFC', '27.JPG', 'www.hdfcbank.com'),
(27, 'Wipro', '25.JPG', 'www.wipro.com'),
(28, 'Coal India', '30.JPG', 'www.coalindia.com'),
(29, 'Hindustan Zinc', '29.JPG', 'www.hindustanzinc.com'),
(30, 'HCL', '312.JPG', 'www.hcl.com'),
(31, 'Accenture ', '32.JPG', 'www.Accenture.com'),
(32, 'samsung', '342.JPG', 'www.samsung.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
